from transparencia import db
from transparencia.models import Documentos


def new_documento(name):
    """
    new_category creates a new Category object given the name
    """
    documentos = Documentos()
    documentos.name = name
    return documentos


def main():
    # list of category names
    documentos = [
        '1.-Normatividad.aplicable.xlsx', '2.-Estructura-Organica.xlsx', '3.-Estructura-Organica_Organigra.xlsx',
        '4.-Obligaciones-aplicables.xlsx', '5.-Objetivos-y-metas-institucion.xlsx', '6.-Indicadores-de-interes-publico.xlsx',
        '7.-Indicadores-de-resultados.xlsx', '8.-Directorio.xlsx', '9.-Remuneracion-bruta-y-neta.xlsx', '10.-Gastos-por-concepto-de-viatic.xlsx',
        '11.-Plazas-vacantes-del-personal-.xlsx', '12.-Total-de-plazas-vacantes-y-oc.xlsx', '13.-Personal-contratado-por-honor.xlsx', '14.-Declaraciones-de-situacion-pa.xlsx',
        '15.-Unidad-de-Transparencia--UT-.xlsx', '16.-Concursos-para-ocupar-cargos-.xlsx', '17.-Padron-de-beneficiarios-de-pr.xlsx', '18.-Programas-sociales.xlsx',
        '19.-Normatividad-laboral.xlsx', '20.-Recursos-publicos-entregados-.xlsx', '21.-Informacion-curricular-y-sanc.xlsx', '22.-Sanciones-administrativas-a-l.xlsx',
        '23.-Servicios-ofrecidos.xlsx', '24.-Tramites-ofrecidos.xlsx', '25.-Presupuesto-asignado-anual.xlsx', '26.-Ejercicio-de-los-egresos-pres.xlsx', '27.-Cuenta-publica.xlsx',
        '28.-Deuda-Publica.xlsx', '29.-Programa-Anual-de-Comunicacio.xlsx', '30.-Utilizacion-de-los-tiempos-of.xlsx', '31.-Hipervinculo-a-informacion-de.xlsx', '32.-Resultados-de-auditorias-real.xlsx',
        '33.-Resultados-de-la-dictaminacio.xlsx', '34.-Personas-que-usan-recursos-pu.xlsx', '35.-Contratacion-de-servicios-de-.xlsx', '36.-Las-concesiones-contratos-con.xlsx', '37.-Procedimientos-de-licitacion-.xlsx',
    ]
    for c in documentos:
        db.session.add(new_documento(c))
    # save all categories to db
    db.session.commit()


if __name__ == '__main__':
    main()
